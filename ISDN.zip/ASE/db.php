<?php
$conn = mysqli_connect("localhost", "root", "", "isdn_rbac_db");

if (!$conn) {
    die("Database connection failed");
}
?>
