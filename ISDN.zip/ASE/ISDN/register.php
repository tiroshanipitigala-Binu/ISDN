<?php
$name     = $_POST['name'];
$email    = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO Users (FullName, Email, PasswordHash, RoleID)
        VALUES ('$name', '$email', '$password', 6)";

$conn->query($sql);

echo "Registration successful";