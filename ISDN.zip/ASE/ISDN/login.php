<?php
session_start();
header("Content-Type: application/json");

require "db.php";

$data = json_decode(file_get_contents("php://input"), true);

$email    = trim($data['email'] ?? '');
$password = trim($data['password'] ?? '');

if ($email === '' || $password === '') {
    echo json_encode(["success" => false, "message" => "Missing credentials"]);
    exit;
}

$sql = "SELECT u.UserID, u.FullName, u.PasswordHash, u.AccountStatus, r.RoleName
        FROM Users u
        INNER JOIN Roles r ON u.RoleID = r.RoleID
        WHERE u.Email = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || !password_verify($password, $user['PasswordHash'])) {
    echo json_encode(["success" => false, "message" => "Invalid email or password"]);
    exit;
}

if ($user['AccountStatus'] !== 'Active') {
    echo json_encode(["success" => false, "message" => "Account is inactive"]);
    exit;
}

// Store session
$_SESSION['user_id'] = $user['UserID'];
$_SESSION['role']    = $user['RoleName'];
$_SESSION['name']    = $user['FullName'];

// Login audit
$conn->prepare(
    "INSERT INTO LoginAudit (UserID, LoginStatus)
     VALUES (?, 'Success')"
)->execute([$user['UserID']]);

echo json_encode([
    "success" => true,
    "role"    => $user['RoleName']
]);