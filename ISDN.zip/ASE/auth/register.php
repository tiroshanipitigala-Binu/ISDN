<?php
include "db.php";

$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = $_POST['role'];

/* 1️⃣ Insert into USERS table */
$user_sql = "INSERT INTO users (email, password, role)
             VALUES ('$email', '$password', '$role')";

if (mysqli_query($conn, $user_sql)) {

    $user_id = mysqli_insert_id($conn); // get generated user_id

    /* 2️⃣ Insert into ROLE-SPECIFIC table */
    switch ($role) {

        case "retail_customer":
            $sql = "INSERT INTO retail_customers (user_id, owner_name)
                    VALUES ('$user_id', '$name')";
            break;

        case "rdc_staff":
            $sql = "INSERT INTO rdc_staff (user_id, designation)
                    VALUES ('$user_id', 'RDC Clerk')";
            break;

        case "logistics_team":
            $sql = "INSERT INTO logistics_team (user_id, route_area)
                    VALUES ('$user_id', 'Central')";
            break;

        case "sales_representative":
            $sql = "INSERT INTO sales_representatives (user_id, assigned_region)
                    VALUES ('$user_id', 'Western')";
            break;

        case "driver":
            $sql = "INSERT INTO drivers (user_id, status)
                    VALUES ('$user_id', 'Available')";
            break;

        case "head_office_manager":
            $sql = "INSERT INTO head_office_managers (user_id, department)
                    VALUES ('$user_id', 'Operations')";
            break;
    }

    mysqli_query($conn, $sql);

    echo "Registration Successful";

} else {
    echo "Error occurred";
}
?>
