<?php
session_start();
include "db.php";

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email'";
$result = mysqli_query($conn, $sql);
$user = mysqli_fetch_assoc($result);

if ($user && password_verify($password, $user['password'])) {

    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['role'] = $user['role'];

    // Redirect based on role
    switch ($user['role']) {
        case "retail_customer":
            header("Location: retail_dashboard.php");
            break;
        case "rdc_staff":
            header("Location: rdc_dashboard.php");
            break;
        case "logistics_team":
            header("Location: logistics_dashboard.php");
            break;
        case "sales_representative":
            header("Location: sales_dashboard.php");
            break;
        case "driver":
            header("Location: driver_dashboard.php");
            break;
        case "head_office_manager":
            header("Location: manager_dashboard.php");
            break;
    }

} else {
    echo "Invalid login";
}
?>
